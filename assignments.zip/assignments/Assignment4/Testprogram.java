package Assignment4;

import java.util.Scanner;

public class Testprogram {
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		int year;
		double fee,pay;
		String program,name,address,school;
		System.out.println("Enter the name: ");
		name=sc.nextLine();
		System.out.println("Enter address: ");
		address=sc.nextLine();
		System.out.println("Enter year: ");
		year=sc.nextInt();
		System.out.println("Enter fee: ");
		fee=sc.nextDouble();
		System.out.println("Enter the name of school: ");
		school=sc.next();
		System.out.println("Enter the amount: ");
		pay=sc.nextDouble();
		System.out.println("Enter program: ");
		program=sc.next();
		Student stud= new Student(name,program,address,year,fee);
		Staff stf= new Staff(name,address,school,pay);
		String str= stud.toString();
		System.out.println(str);
		String str1= stf.toString();
		System.out.println(str1);
	}

}
