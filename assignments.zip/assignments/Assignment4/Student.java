package Assignment4;

public class Student extends Person {
	int year;
	double fee;
	String program;
	Student(String name, String program, String address, int year, double fee)
	{
		super(name,address);
		this.year=year;
		this.fee=fee;
		this.program=program;
	}
	public String getProgram() {
		return program;
	}
	public void setProgram(String program) {
		this.program=program;
	}
	public int getYear() 
	{
		return year;
	}
	public void setyear(int year) {
		this.year=year;
	}
	public double getFee() {
		return fee;
	}
	public void setFee(double fee) {
		this.fee=fee;
	}
	public String toString() {
		return ("Student[Person[name= "+name+", address= "+address+"], program= "+program+", year= "+year+", fee= "+fee);
	}
}
