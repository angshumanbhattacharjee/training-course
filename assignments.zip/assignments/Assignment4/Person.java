package Assignment4;

public class Person {
	String name;
	String address;
	Person(String name, String address){
		this.name=name;
		this.address=address;
	}
	public String getName() {
		return name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address=address;
	}
	public String toString() {
		String str= "Person[name= "+name+", address= "+address+"]";
		return str;
	}
}
