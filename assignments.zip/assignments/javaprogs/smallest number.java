﻿import java.util.*;
public class JavaExample 
{
    public static void main(String[] args) 
    {
        int num1, num2, num3, result;
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter First Number:");
        num1 = scanner.nextInt();
        System.out.println("Enter Second Number:");
        num2 = scanner.nextInt();
        System.out.println("Enter Third Number:");
        num3 = scanner.nextInt();
        
        result = num1 < num2 ?(num1<num3?num1:num3):(num2<num3?num2:num3);
        System.out.println("Smallest Number is:"+result);
    }
}