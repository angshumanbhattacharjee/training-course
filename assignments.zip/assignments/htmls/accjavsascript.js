function display(){
	var salary=Document.getElementById("acctype").value;
	if(salary=="savings") {
		Document.getElementById("savingstype").hidden="";
	}
	else{
		if(salary=="current") {
			Document.getElementById("overdraft").hidden="";
		}
	}
}