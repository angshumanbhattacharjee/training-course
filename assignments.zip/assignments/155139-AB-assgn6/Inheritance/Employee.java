package Inheritance;

public class Employee {
	long employeeId,employeePhone;
	String employeeName,employeeAddress;
	double basicSalary,specialAllowance=250.8,Hra=1000.5;
	public Employee() {
		
	}
	public Employee(long id, String name, String address, long phone) {
		this.employeeId=id;
		this.employeeName=name;
		this.employeeAddress=address;
		this.employeePhone=phone;
	}
	public double calculateSalary() {
		double salary=basicSalary+(basicSalary*specialAllowance/100)+(basicSalary*Hra/100);
		return salary;
	}
	public void calculateTransportAllowance() {
		double transportAllowance=0.10*basicSalary;
		System.out.println("Salary after calculating transport allowance: Rs."+transportAllowance);
	}
}
