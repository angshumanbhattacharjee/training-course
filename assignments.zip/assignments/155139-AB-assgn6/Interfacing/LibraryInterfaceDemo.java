package Interfacing;

public class LibraryInterfaceDemo {
	public static void main(String[] args) {
		KidUsers kid1= new KidUsers(10,"Kids");
		KidUsers kid2= new KidUsers(18,"Fiction");
		AdultUsers alt1= new AdultUsers(5,"Kids");
		AdultUsers alt2= new AdultUsers(23,"Fiction");
		kid1.registerAccount();
		kid2.registerAccount();
		alt1.registerAccount();
		alt2.registerAccount();
		kid1.requestBook();
		kid2.requestBook();
		alt1.requestBook();
		alt2.requestBook();
	}	
}
