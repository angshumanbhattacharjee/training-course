package employeeSpringAddress;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class EmployeeTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext ctx=new ClassPathXmlApplicationContext("Beans.xml");  
	      
	    EmployeeDao dao=(EmployeeDao)ctx.getBean("empList");  
	    int status=dao.saveEmployee(new Employee("100","Angshuman",20000,1000,"java","12345"));  
	    System.out.println(status);  
	}

}
