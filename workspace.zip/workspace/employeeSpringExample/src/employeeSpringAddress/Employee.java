package employeeSpringAddress;

public class Employee {
	
	String eid,name,dept,phone;
	int comission,salary;
	public Employee(String eid, String name, int salary, int comission, String dept, String phone) {
		this.eid = eid ;
		this.name = name;
		this.salary = salary;
		this.comission = comission;
		this.dept = dept;
		this.phone = phone;
		
		
	}
	public String getEid() {
		return eid;
	}
	public void setEid(String eid) {
		this.eid = eid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public int getComission() {
		return comission;
	}
	public void setComission(int comission) {
		this.comission = comission;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	
	
}
