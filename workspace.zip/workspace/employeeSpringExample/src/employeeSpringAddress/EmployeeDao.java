package employeeSpringAddress;

import org.springframework.jdbc.core.JdbcTemplate;

public class EmployeeDao {

	private JdbcTemplate jdbcTemplate;  
	  
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {  
	    this.jdbcTemplate = jdbcTemplate;  
	}  
	
	public int saveEmployee(Employee e){  
	    String query="insert into EmployeeTable values('"+e.getEid()+"','"+e.getName()+"','"+e.getSalary()+"','"+e.getComission()+"','"+e.getDept()+"','"+e.getPhone()+"')";  
	    return jdbcTemplate.update(query);  
	}  
}
