package com.capgemini.newSpringExample;

public class Employee {
	String empName;
	String empId;
	double empSal;
	
	public Employee() {
		System.out.println("Default Constructor");
	}
	
	public Employee(String empName, String empId, double empSal) {
		this.empName = empName;
		this.empId = empId;
		this.empSal = empSal;
		System.out.println("Parametrized Constructor");
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public void setEmpSal(double empSal) {
		this.empSal = empSal;
	}

	@Override
	public String toString() {
		return "Employee [empName=" + empName + ", empId=" + empId + ", empSal=" + empSal + "]";
	}
	
	
}

