package com.capgemini.dal;

public class InvalidUserException extends Exception {
	public InvalidUserException() {
		System.out.println("Invalid User");
		// TODO Auto-generated constructor stub
	}
}
