package Junit_codes;

import static org.junit.Assert.*;

import org.junit.Test;

public class AdditionTest {

	@Test
	public void test1() {
		int result=Addition.add(6, 4);
		assertEquals(10,result);
	}
	@Test
	public void test2() {
		int result=Addition.add(6, 4);
		assertEquals(10,result);
	}
}
