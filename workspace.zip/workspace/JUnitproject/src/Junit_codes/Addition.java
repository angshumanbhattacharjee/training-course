package Junit_codes;

import java.util.Scanner;

public class Addition {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in); 
		System.out.println("Enter first number");
		int a=sc.nextInt();
		System.out.println("Enter second number");
		int b=sc.nextInt();
		System.out.println(add(a,b));
	}
	public static int add(int a, int b) {
		return a+b;
	}

}
