package com.capgemini.restaurantTests;

import com.capgemini.restaurant.Restaurant;

public class RestaurantTest {
	
	public static void main(String[] args) {
		
		Restaurant rt= new Restaurant();
		//rt.query1();
//		rt.query2();
//		rt.query3();
//		rt.query4();
		//rt.query5();
		rt.query6();
//		rt.query7();
//		rt.query8();
//		rt.query9();
		//rt.query10();
	}
}
