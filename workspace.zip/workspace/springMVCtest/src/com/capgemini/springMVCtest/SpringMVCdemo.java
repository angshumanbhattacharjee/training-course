package com.capgemini.springMVCtest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class SpringMVCdemo {
   @RequestMapping( "/")
   public String printHello() {
      
      return "demo";
   }
   
   @RequestMapping( "/ab")
   public String printHola() {
      
      return "main-menu";
   }
   
   @RequestMapping( "/abc")
   public String printHi() {
      
      return "display";
   }
}
