package employee_Firm;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

public class EmployeeTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BeanFactory beanfact= new XmlBeanFactory(new ClassPathResource("Context.xml"));
		
		Employee employee= (Employee)beanfact.getBean("employeeObj");
		
		System.out.println(employee);
	}

}
