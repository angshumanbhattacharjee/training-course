package assgn5;

import java.util.*;

public class TestShape {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		
		double r,l,w,s;
		String col;
		//boolean fill;
		System.out.println("Enter the radius of circle: ");
		r= sc.nextDouble();
		System.out.println("Enter the color of circle: ");
		col= sc.next();
		System.out.println("Enter if it is filled or not: ");
		boolean fill= sc.nextBoolean();
		System.out.println("Enter the length of rectangle: ");
		l= sc.nextDouble();
		System.out.println("Enter the width of rectangle: ");
		w= sc.nextDouble();
		System.out.println("Enter the side of square: ");
		s= sc.nextDouble();
		Circle cir= new Circle(r,col,fill);
		Rectangle rect= new Rectangle(w,l,col,fill);
		Square sq= new Square(s,col,fill);
		System.out.println(cir.toString());
		System.out.println(rect.toString());
		System.out.println(sq.toString());
	}

}
