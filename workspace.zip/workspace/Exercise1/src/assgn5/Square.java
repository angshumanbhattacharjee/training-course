package assgn5;

public class Square extends Rectangle {
	double side;
	String color;
	boolean filled;
	Square(){
		
	}
	Square(double side){
		this.side=side;
	}
	Square(double side, String color, boolean filled){
		width=side;
		this.color=color;
		this.filled=filled;
		length=side;
	}
	public double getSide() {
		return side;
	}
	public void setSide(double side) {
		this.side = side;
	}
	public void setWidth(double side) {
		width=side;
	}
	public void setLength(double side) {
		length=side;
	}
	public String toString() {
		return ("Area of Square is: "+getArea()+"units and the Perimeter of the square is: "+getPerimeter()+" units");
	}
}
