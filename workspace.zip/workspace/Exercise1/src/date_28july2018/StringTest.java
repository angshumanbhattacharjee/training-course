package date_28july2018;

import java.util.Scanner;

public class StringTest {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		String str;
		
		while(true) {
			System.out.println("Enter a string: ");
			str= sc.next();
			if(str.equals("DONE")) System.exit(0);
			else {
				try {
					if(str.length()>20) throw new StringTooLongException();
					}
					catch(StringTooLongException c) {
						c.getMessage();
					}
			}
		}
	}

}
