package date_28july2018;

public class InvalidInputException extends Exception{
	public InvalidInputException(){
		System.out.println("Invalid input");
		System.exit(0);
	}
}
