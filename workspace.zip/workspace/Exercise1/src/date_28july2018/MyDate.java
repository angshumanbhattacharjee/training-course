package date_28july2018;

public class MyDate {
	int day,month,year;
	MyDate(){
		day=0;
		month=0;
		year=0;
	}
	MyDate(int day, int month, int year){
		this.day=day;
		this.month=month;
		this.year=year;
	}
	void check() {
		try {
			if(month<0 || month>12) {
				throw new InvalidMonthException();
			}
		}
		catch(InvalidMonthException i1){
			i1.getMessage();
		}
		try {
			if(month==1 || month==3|| month==5|| month==7|| month==8|| month==10|| month==12) {
				if(day<0 || day>31 ) throw new InvalidDayException();
				else System.out.println("Valid date");
			}
			else if( month==4|| month==6|| month==9|| month==11) {
				if(day<0 || day>30 ) throw new InvalidDayException();
				else System.out.println("Valid date");
			}
			else if(month==2 && (day<0 || day>28)) {
				throw new InvalidDayException();
			}
			else {
				if((day<0 || day>31)) throw new InvalidDayException();
			}
		}
		catch(InvalidDayException i2){
			i2.getMessage();
		}
	}
}
