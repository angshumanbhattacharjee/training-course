package date_28july2018;

public class InvalidMonthException extends Exception{
	InvalidMonthException(){
		System.out.println("Invalid month is entered.");
	}
}
