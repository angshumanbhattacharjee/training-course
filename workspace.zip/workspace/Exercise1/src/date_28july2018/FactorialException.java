package date_28july2018;

public class FactorialException extends Exception {
	FactorialException(){
		System.out.println("Factorial out of range");
	}
}
