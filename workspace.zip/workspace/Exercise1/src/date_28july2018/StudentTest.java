package date_28july2018;

import java.util.Scanner;

public class StudentTest {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		int age, rollno;
		String name= new String("");
		String course= new String("");
		System.out.println("Enter name: ");
		name= sc.next();
		System.out.println("Enter age: ");
		age= sc.nextInt();
		System.out.println("Enter rollno: ");
		rollno= sc.nextInt();
		System.out.println("Enter course: ");
		course= sc.next();
		Student stud= new Student(name,age,rollno,course);
		stud.check();
	}

}
