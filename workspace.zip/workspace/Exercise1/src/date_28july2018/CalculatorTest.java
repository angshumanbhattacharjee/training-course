package date_28july2018;

public class CalculatorTest {

	public static void main(String[] args) {
		MyCalculator calc = new MyCalculator();
		System.out.println(calc.power(3, 5));
		System.out.println(calc.power(2, 4));
		calc.power(0, 0);
		calc.power(-1, -2);
		calc.power(-1, 3);
	}

}
