package date_28july2018;

public class Factorial {
	int num;
	Factorial(int num){
		this.num=num;
	}
	int getFactorial(int num) {
	try {
		if(num<2) {
			throw new InvalidInputException();
		}
	}
	catch(InvalidInputException e1) {
		e1.getMessage();
	}
	try {
		if(num>16) {
			throw new FactorialException();
		}
	}
	catch(FactorialException e2) {
		e2.getMessage();
	}
	
		int fact=1;
		for(int i=num;i>0;i--) {
			fact=fact*i;
		}
		return fact;
	}
}
