package date_28july2018;

public class StringTooLongException extends Exception{
	StringTooLongException(){
		System.out.println("String has too many characters");
		System.exit(0);
	}
}
