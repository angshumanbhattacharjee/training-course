package date_28july2018;

public class Eitheronezero extends Exception {
	Eitheronezero(){
		System.out.println("java.lang.Exception: n or p should not be zero");
	}
}
