package date_28july2018;

public class AgeNotWithinRangeException extends Exception {
	AgeNotWithinRangeException(){
		System.out.println("Age should be between 15yrs and 21yrs");
	}
}
