package date_28july2018;

public class MyCalculator {
	int i;
	long pow=1;
	public long power(int n, int p) {
		try {
			if(n==0 && p==0) {
				throw new Allzero();
			}
			if(n<0 || p<0) {
				throw new Eitheronenegative();
			}
			if(n==0 || p==0) {
				throw new Eitheronezero();
			}
			
		}
		catch(Allzero j1) {
			j1.getMessage();
		}
		catch(Eitheronenegative j2) {
			j2.getMessage();
		}
		catch(Eitheronezero j3) {
			j3.getMessage();
		}
		/*for(i=1;i<=p;i++) {
			pow=pow*n;
		}*/
		pow=(long)Math.pow(n, p);
		return pow;
	}
}
