package date_28july2018;

public class InvalidDayException extends Exception{
	InvalidDayException(){
		System.out.println("Invalid day is entered.");
	}
}
