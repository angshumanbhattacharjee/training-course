package date_28july2018;

import java.util.Scanner;

public class FloatingException extends Exception{
	FloatingException(){
		System.out.println("Wrong input");
		System.exit(0);
	}

}
