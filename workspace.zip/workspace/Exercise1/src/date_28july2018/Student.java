package date_28july2018;

public class Student {
	int age,rollno;
	String name,course;
	public boolean isAlpha(String name) {
		return (name.matches("[a-zA-Z]+"));
	}
	Student(){
		
	}
	Student(String name, int age, int rollno, String course){
		this.age=age;
		this.name=name;
		this.rollno=rollno;
		this.course=course;
	}
	public void check() 
	{
		try
		{
			if(age<15 || age>21) 
			{
				throw new AgeNotWithinRangeException();
			}
			
			System.out.println("Entered details are correct.");
		}
		catch(AgeNotWithinRangeException a) 
		{
			a.getMessage();
		}
		try {
			if(!(isAlpha(name))) 
			{
				throw new NameNotValidException();
			}
		}
		catch(NameNotValidException b) 
		{
			b.getMessage();
		}
	}
}
