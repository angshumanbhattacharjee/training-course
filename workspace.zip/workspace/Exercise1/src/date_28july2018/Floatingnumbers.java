package date_28july2018;

import java.util.Scanner;

public class Floatingnumbers {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		int l;
		System.out.println("How many inputs u want to insert: ");
		l=sc.nextInt();
		String arr[]= new String[l];
		System.out.println("Enter the values: ");
		int c=1; float sum= 0;
		for(int i=0;i<l;i++) {
			arr[i]=sc.next();
			
			if(c>1) {
			if(!(arr[i].matches("[0-9]+[.]+[0-9]"))) {
				c++;
				try {
				if(c==2) throw new FloatingException();
				}
				catch(FloatingException f) {
					f.getMessage();
				}
				
			}
			}
			float y=Float.parseFloat(arr[i]);
			sum=sum+y;
		}
	}

}
