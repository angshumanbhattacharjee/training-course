package date_28july2018;

import java.util.Scanner;

public class DateTest {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		int day,month,year;
		System.out.println("Enter day: ");
		day= sc.nextInt();
		System.out.println("Enter month: ");
		month= sc.nextInt();
		System.out.println("Enter year: ");
		year= sc.nextInt();
		MyDate d= new MyDate(day,month,year);
		d.check();
	}

}
