package date_28july2018;

public class Allzero extends Exception {
	Allzero(){
		System.out.println("java.lang.Exception: n and p should not be zero.");
	}
}
