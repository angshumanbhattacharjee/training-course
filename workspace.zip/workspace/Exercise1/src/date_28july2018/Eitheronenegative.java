package date_28july2018;

public class Eitheronenegative extends Exception {
	Eitheronenegative(){
		System.out.println("java.lang.Exception: n or p should not be negative.");
	}
}
