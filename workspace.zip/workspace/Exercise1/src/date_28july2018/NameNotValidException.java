package date_28july2018;

public class NameNotValidException extends Exception {
	NameNotValidException(){
		System.out.println("Name is invalid.");
	}
}
