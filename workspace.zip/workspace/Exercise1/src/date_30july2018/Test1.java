package date_30july2018;

public class Test1 {

	public static void main(String[] args) {
		Laptop l1= new Laptop("hp","notebook","windows","i5");
		Laptop l2= new Laptop("apple","mac","macos","i5");
		
		Car c1= new Car("porsche","carrera gt",2014,500);
		Car c2= new Car("bugati","veyron",2014,1500);
		
		Television t1= new Television("Sony","LCD",800,true);
		Television t2= new Television("Samsung","LED",200,false);
		
		CellPhone ap1= new CellPhone("Samsung","note9plus","dual speakers","android",45000);
		CellPhone ap2= new CellPhone("sony","xperia","sound-camera","android",15000);
		
		School sc1= new School("bdm international","kolkata","south24pgs","awesome");
		School sc2= new School("dps","kolkata","ruby","awesome");
	}

}
