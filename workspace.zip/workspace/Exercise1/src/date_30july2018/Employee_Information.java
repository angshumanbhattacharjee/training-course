package date_30july2018;

public class Employee_Information {
	int empID,Employee_salary,employee_comm;
	String Employee_name,Employee_designation;
	
	public Employee_Information(int empID, int employee_salary, int employee_comm, String employee_name,
			String employee_designation) {
		this.empID = empID;
		this.Employee_salary = employee_salary;
		this.employee_comm = employee_comm;
		this.Employee_name = employee_name;
		this.Employee_designation = employee_designation;
	}
	public int getEmpID() {
		return empID;
	}
	public void setEmpID(int empID) {
		this.empID = empID;
	}
	public int getEmployee_salary() {
		return Employee_salary;
	}
	public void setEmployee_salary(int employee_salary) {
		Employee_salary = employee_salary;
	}
	public int getEmployee_comm() {
		return employee_comm;
	}
	public void setEmployee_comm(int employee_comm) {
		this.employee_comm = employee_comm;
	}
	public String getEmployee_name() {
		return Employee_name;
	}
	public void setEmployee_name(String employee_name) {
		Employee_name = employee_name;
	}
	public String getEmployee_designation() {
		return Employee_designation;
	}
	public void setEmployee_designation(String employee_designation) {
		Employee_designation = employee_designation;
	}
}
