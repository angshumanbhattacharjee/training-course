package date_30july2018;

public class School {
	String name,city,school_district,greatSchoolRanking;

	public School(String name, String city, String school_district, String greatSchoolRanking) {
		this.name = name;
		this.city = city;
		this.school_district = school_district;
		this.greatSchoolRanking = greatSchoolRanking;
	}
}
