package date_30july2018;

public class Laptop {
	String company,model,operatingsystem,processor;

	public Laptop(String company, String model, String operatingsystem, String processor) {
		this.company = company;
		this.model = model;
		this.operatingsystem = operatingsystem;
		this.processor = processor;
	}
	
}
