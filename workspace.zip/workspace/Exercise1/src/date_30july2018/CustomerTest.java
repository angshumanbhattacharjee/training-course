package date_30july2018;

import java.util.Scanner;

public class CustomerTest {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		String name,no,category;
		System.out.println("Enter customer no: ");
		no= sc.next();
		System.out.println("Enter customer name: ");
		name= sc.next();
		System.out.println("Enter customer category: ");
		category= sc.next();
		Customer cust= new Customer(no,name,category);
		System.out.println("Customer no: "+cust.getCustNo());
		System.out.println("Customer name: "+cust.getCustName());
		System.out.println("Customer category: "+cust.getCategory());
	}

}
