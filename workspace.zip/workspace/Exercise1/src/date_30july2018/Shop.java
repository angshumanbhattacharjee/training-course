package date_30july2018;

public class Shop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
