package date_30july2018;

public class CellPhone {
	String company,model,description,operatingSystem;
	int price;
	public CellPhone(String company, String model, String description, String operatingSystem, int price) {
		
		this.company = company;
		this.model = model;
		this.description = description;
		this.operatingSystem = operatingSystem;
		this.price = price;
	}
	
}
