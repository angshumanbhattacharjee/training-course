package date_30july2018;

import java.util.*;
public class ListIteratorDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList a= new LinkedList();
		
			a.add("krishna");
			a.add("venky");
			a.add("chiru");
			a.add("nag");
		System.out.println(a);
		ListIterator itr=a.listIterator();
		while(itr.hasNext()) {
			String s= (String)itr.next();
			if(s.equals("venky")) itr.remove();
		}
		System.out.println(a);
	}
}
