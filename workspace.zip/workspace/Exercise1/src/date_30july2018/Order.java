package date_30july2018;

import java.util.Date;

public class Order {
	private String orderId,orderDetails;
	private Date orderDate;
	public Order(String orderId, String orderDetails, Date orderDate) {
		this.orderId = orderId;
		this.orderDetails = orderDetails;
		this.orderDate = orderDate;
		try {
			if(orderId.length()<3) {
				throw new OrderNotValidException();
			}
			if(orderId.charAt(0)=='O') {
				System.out.println("Valid");
			}
			else throw new OrderNotValidException();
		}
		catch(OrderNotValidException o) {
			o.getMessage();
		}
	}
	
}
