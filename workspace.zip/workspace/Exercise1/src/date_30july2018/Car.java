package date_30july2018;

public class Car {
	String maker,model;
	int year,price;
	public Car(String maker, String model, int year, int price) {
		this.maker = maker;
		this.model = model;
		this.year = year;
		this.price = price;
	}
	
}
