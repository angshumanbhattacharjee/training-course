package date_30july2018;

public class Television {
String company,type;
int price;
boolean three_d_enabled;
public Television(String company, String type, int price, boolean three_d_enabled) {
	this.company = company;
	this.type = type;
	this.price = price;
	this.three_d_enabled = three_d_enabled;
}

}
