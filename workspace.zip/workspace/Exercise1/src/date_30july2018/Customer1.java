package date_30july2018;

public class Customer1 {
	private int custno;
	private String custname;
	public Customer1(int custno, String custname) {
		this.custno = custno;
		this.custname = custname;
	}
	
}
