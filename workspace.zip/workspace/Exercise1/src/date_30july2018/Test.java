package date_30july2018;

import java.util.ArrayList;

public class Test {

	public static void main(String[] args) {
		
		Employee_Information e= new Employee_Information(1, 10000, 1000, "Ashok", "abc");
		MMASaving_Account m= new MMASaving_Account(1, 10000, "Ashok", true);
		ArrayList<Employee_Information> ar= new ArrayList<Employee_Information>();
		ArrayList<MMASaving_Account> ar1= new ArrayList<MMASaving_Account>();
		if(e.Employee_name==m.accountholder_name) {
			ar.add(e);
			ar1.add(m);
			for(Employee_Information e1:ar) {
				System.out.println(e.Employee_name);
				System.out.println(e.Employee_salary);
				System.out.println(e.empID);
				System.out.println(e.employee_comm);
				System.out.println(e.Employee_designation);
			}
		}
		
	}

}
