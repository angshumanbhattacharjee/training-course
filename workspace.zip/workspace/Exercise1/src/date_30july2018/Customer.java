package date_30july2018;

import date_28july2018.InvalidInputException;

public class Customer {
	private String custNo,custName,category;
	Customer(String custNo, String custName, String category){
		this.custNo=custNo;
		this.custName=custName;
		this.category=category;
		try {
			if((custNo.charAt(0)=='C' || custNo.charAt(0)=='c') && (custName.length()>=4) && (category.equals("Platinum")==true || category.equals("Gold")==true || category.equals("Silver")==true)) {
				System.out.println("valid");
			}
			else {
				throw new InvalidInputException();
			}
		}
		catch(InvalidInputException i) {
			i.getMessage();
		}
	}
	public String getCustNo() {
		return custNo;
	}
	public String getCustName() {
		return custName;
	}
	public String getCategory() {
		return category;
	}
}
