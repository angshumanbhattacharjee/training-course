package date_30july2018;

public class SavingAccount {
	double acc_balance;
	String accountholdername;
	int acc_id;
	boolean isSalaryAccount;
	SavingAccount(double bal, int i, String name, boolean isSal) {
		this.acc_balance=bal;
		this.acc_id=i;
		this.accountholdername=name;
		this.isSalaryAccount=isSal;
	}
	public double getAcc_balance() {
		return acc_balance;
	}
	public void setAcc_balance(double acc_balance) {
		this.acc_balance = acc_balance;
	}
	public int getAcc_id() {
		return acc_id;
	}
	public void setAcc_id(int acc_id) {
		this.acc_id = acc_id;
	}
	public String getAccountholdername() {
		return accountholdername;
	}
	public void setAccountholdername(String accountholdername) {
		this.accountholdername = accountholdername;
	}
	public boolean isSalaryAccount() {
		return isSalaryAccount;
	}
	public void setSalaryAccount(boolean isSalaryAccount) {
		this.isSalaryAccount = isSalaryAccount;
	}
	public double withdraw(double amt) {
		acc_balance=acc_balance-amt;
		return acc_balance;
	}
	public double deposit(double amt1) {
		acc_balance=acc_balance+amt1;
		return acc_balance;
	}
}
