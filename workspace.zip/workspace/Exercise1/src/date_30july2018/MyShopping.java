package date_30july2018;

import java.util.Hashtable;

public class MyShopping {
	private Hashtable<Customer,Order> hash= new Hashtable<Customer,Order>();
	
}
