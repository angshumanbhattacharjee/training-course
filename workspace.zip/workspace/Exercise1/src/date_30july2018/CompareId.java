package date_30july2018;

import java.util.*;

public class CompareId implements Comparator<SavingAccount>{
	
@Override
	public int compare(SavingAccount e1, SavingAccount e2) {
		if(e1.getAcc_id() > e2.getAcc_id()){
            return 1;
        } else {
            return -1;
        }
	}

	
}
