package date_30july2018;

public class OrderNotValidException extends Exception {
	OrderNotValidException(){
		System.out.println("Invalid");
	}
}
