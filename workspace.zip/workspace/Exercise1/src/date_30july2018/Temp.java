package date_30july2018;

import java.util.Scanner;
import java.util.TreeMap;

public class Temp {

	public static void main(String[] args) {
		int[] id=new int[3];
		String[] str=new String[3];
		Product p[]= new Product[3];
		Scanner sc= new Scanner(System.in);
		for(int i=0;i<3;i++) {
			System.out.println("Enter id"+(i+1)+": ");
			id[i]=sc.nextInt();
			System.out.println("Enter name "+(i+1)+": ");
			str[i]=sc.next();
			p[i] =  new Product(id[i],str[i]);
		}
		TreeMap<Integer, String> tmap = new TreeMap<Integer, String>();
		for(int i=0;i<3;i++) {
			tmap.put(p[i].prodId,p[i].prodName);
		}
		System.out.println(tmap);
	}

}
