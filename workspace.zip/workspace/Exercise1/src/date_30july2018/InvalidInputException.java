package date_30july2018;

public class InvalidInputException extends Exception {
	public InvalidInputException(){
		System.out.println("Invalid Input");
	}
}
