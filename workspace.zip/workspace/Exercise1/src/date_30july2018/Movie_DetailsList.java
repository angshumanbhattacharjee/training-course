package date_30july2018;

import java.util.*;

public class Movie_DetailsList {
	static ArrayList<Movie_Details> ar= new ArrayList<Movie_Details>();
	//static Movie_Details movie;
	public static void main(String[] args) 
	{
		Movie_Details m1= new Movie_Details("fv","khan","kajol","drama");
		Movie_Details m2= new Movie_Details("erfr","tom cruise","katherine","sci-fi");
		Movie_DetailsList.add_Movie(m1,m2);
		Movie_DetailsList.Remove_Movie(m1,m2);
		Movie_DetailsList.RemoveAll_Movie();
		boolean b=Movie_DetailsList.find_movie_by_name_Movie("fv");
		System.out.println(b);
		boolean b1=Movie_DetailsList.find_movie_by_genre_Movie("drama");
		System.out.println(b1);
	}
	public static void add_Movie(Movie_Details m1,Movie_Details m2) 
	{
		ar.add(m1);
		ar.add(m2);
		for(Movie_Details m:ar) {
			System.out.println(m.mov_Name);
		}
	}
	public static void Remove_Movie(Movie_Details m1,Movie_Details m2)
	{
		ar.remove(m1);
		ar.remove(m2);
		for(Movie_Details m:ar) {
			System.out.println(m.mov_Name);
		}
	}
	public static void RemoveAll_Movie()
	{
		ar.removeAll(ar);
		for(Movie_Details m:ar) {
			System.out.println(m);
		}
	}
	public static boolean find_movie_by_name_Movie(String movie) {
		boolean b = false;
		for(Movie_Details mv:ar)
		{
			if(movie.equals(mv.mov_Name))
				return true;
			else return false;
		}
		
		
	}
	public static boolean find_movie_by_genre_Movie(String genre) {
		boolean b = false;
		for(Movie_Details mv:ar)
		if(genre.equals(mv.genre)) b=true;
		else b=false;
		return b;
	}
}
