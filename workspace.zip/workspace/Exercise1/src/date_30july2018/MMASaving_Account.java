package date_30july2018;

public class MMASaving_Account {
	int account_id,account_balance;
	String accountholder_name;
	boolean isSalaryAccount;
	
	public MMASaving_Account(int account_id, int account_balance, String accountholder_name, boolean isSalaryAccount) {
		this.account_id = account_id;
		this.account_balance = account_balance;
		this.accountholder_name = accountholder_name;
		this.isSalaryAccount = isSalaryAccount;
	}
	public int getAccount_id() {
		return account_id;
	}
	public void setAccount_id(int account_id) {
		this.account_id = account_id;
	}
	public int getAccount_balance() {
		return account_balance;
	}
	public void setAccount_balance(int account_balance) {
		this.account_balance = account_balance;
	}
	public String getAccountholder_name() {
		return accountholder_name;
	}
	public void setAccountholder_name(String accountholder_name) {
		this.accountholder_name = accountholder_name;
	}
	public boolean isSalaryAccount() {
		return isSalaryAccount;
	}
	public void setSalaryAccount(boolean isSalaryAccount) {
		this.isSalaryAccount = isSalaryAccount;
	}
	
}
