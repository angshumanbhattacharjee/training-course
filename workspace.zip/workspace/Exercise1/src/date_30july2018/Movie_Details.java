package date_30july2018;

public class Movie_Details {
	String mov_Name,lead_actor,lead_actresses,genre;
	public Movie_Details(String mov_name, String lead_actor, String lead_actresses, String genre) {
		this.genre=genre;
		this.lead_actor=lead_actor;
		this.lead_actresses=lead_actresses;
		this.mov_Name=mov_name;
	}
	public String getMov_Name() {
		return mov_Name;
	}
	public void setMov_Name(String mov_Name) {
		this.mov_Name = mov_Name;
	}
	public String getLead_actor() {
		return lead_actor;
	}
	public void setLead_actor(String lead_actor) {
		this.lead_actor = lead_actor;
	}
	public String getLead_actresses() {
		return lead_actresses;
	}
	public void setLead_actresses(String lead_actresses) {
		this.lead_actresses = lead_actresses;
	}
	public String getGenre() {
		return genre;
	}
	public void setGenre(String genre) {
		this.genre = genre;
	}
	
}
