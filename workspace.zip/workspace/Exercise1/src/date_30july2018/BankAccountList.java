package date_30july2018;

import java.util.TreeSet;

public class BankAccountList {

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		
		SavingAccount sa= new SavingAccount(1000,1,"angshu",true);
		SavingAccount sa1= new SavingAccount(1001,2,"angsh",true);
		SavingAccount sa2= new SavingAccount(1003,3,"anshu",false);
		SavingAccount sa3= new SavingAccount(1050,4,"ashu",true);
		TreeSet<SavingAccount> al=new TreeSet<SavingAccount>(new CompareId());
		al.add(sa);
		al.add(sa1);
		al.add(sa2);
		al.add(sa3);
		
		sa.withdraw(20);
		sa.deposit(50);
		sa1.withdraw(200);
		sa1.deposit(120);
		
		for(SavingAccount e:al)
		{
			System.out.println(e.accountholdername);
			System.out.println(e.acc_balance);
		}
		
	}

}
