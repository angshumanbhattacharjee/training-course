package date_30july2018;

import java.util.*;

public class TreeSet extends AbstractSet implements NavigableSet,SortedSet 
{

	@Override
	public Comparator comparator() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object first() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object last() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object ceiling(Object arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Iterator descendingIterator() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public NavigableSet descendingSet() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object floor(Object arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public SortedSet headSet(Object arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public NavigableSet headSet(Object arg0, boolean arg1) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object higher(Object arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object lower(Object arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object pollFirst() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object pollLast() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public SortedSet subSet(Object arg0, Object arg1) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public NavigableSet subSet(Object arg0, boolean arg1, Object arg2, boolean arg3) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public SortedSet tailSet(Object arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public NavigableSet tailSet(Object arg0, boolean arg1) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Iterator iterator() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return 0;
	}
	
}
