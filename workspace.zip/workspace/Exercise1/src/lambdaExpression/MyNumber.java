package lambdaExpression;

public interface MyNumber {
	double getSum(int a, int b);
}
