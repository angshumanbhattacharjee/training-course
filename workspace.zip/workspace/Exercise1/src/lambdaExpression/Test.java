package lambdaExpression;

import java.util.HashSet;
import java.util.Set;

public class Test {
	a(){print();}
	private void print() {
		System.out.println("A");
	}
	
	 
}
class B extends a{
	int i=Math.round(3.5f);
	public static void main(String[] args) {
		a A= new B();
		A.print();
	}
}