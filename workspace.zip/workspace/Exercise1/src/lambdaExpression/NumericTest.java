package lambdaExpression;

public interface NumericTest {
	boolean checknum(int a,int b);
}
