package lambdaExpression;

public class LambdaActivity {
	public static void main(String[] args) {
		MyNumber mynum;
		mynum= (a,b)-> a+b;
		System.out.println(mynum.getSum(5,7));
		mynum= (a,b)-> Math.random()*10;
		System.out.println(mynum.getSum(5,7));
	}
}
