package SalesMarket;

public class Supplier {
	int amount,quantityOrder;
	String supplierId,supplierName,supplierAddress,orderId;
	public void addSupplier() {
		
	}
	public void removeSupplier() {
		
	}
	public void updateSupplier() {
		
	}
}
