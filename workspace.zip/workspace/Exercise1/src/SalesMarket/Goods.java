package SalesMarket;

public class Goods {
	String goodsId,goodsName;
	int goodsQuantity,goodsPrice;
	public void addGoods() {
		
	}
	public void removeGoods() {
		
	}
	public void orderGoods() {
	
	}
	public void updateGoods() {
	
	}
}
