package SalesMarket;

public class Retailer {
	String retailerName,retailerAddress;
	public void viewGoods() {
		
	}
	public void viewCustomer() {
		
	}
	public void viewSupplier() {
		
	}
}
