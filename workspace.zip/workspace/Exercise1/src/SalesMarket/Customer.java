package SalesMarket;

public class Customer extends Goods {

}
