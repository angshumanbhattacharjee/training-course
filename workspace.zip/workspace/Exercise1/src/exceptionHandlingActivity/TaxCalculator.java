package exceptionHandlingActivity;

public class TaxCalculator {
	public double calculateTax(String empName, int empSal, boolean isIndian ){
			double taxAmount = 0;
			try {
				if(isIndian==false)
					throw new CountryNotValidException();
				if(empName.equals("")) {
					throw new EmployeeNameInvalidException();
				}
				
			} 
			catch (CountryNotValidException e) {
				e.getMessage();
			}
			catch (EmployeeNameInvalidException e1) {
				e1.getMessage();
			}
			
			if(empSal>100000 && isIndian==true) {
				 taxAmount=empSal*0.08;
			}
			else if((empSal>50000 && empSal<100000) && isIndian==true) {
				 taxAmount=empSal*0.06;
			}
			else if((empSal>30000 && empSal<50000) && isIndian==true) {
				taxAmount=empSal*0.05;
			}
			else if((empSal>10000 && empSal<30000) && isIndian==true) {
				taxAmount=empSal*0.04;
			}
			else if (empSal<10000 && isIndian==true){
				try {
					throw new TaxNotEligibleException();
				}
				catch (TaxNotEligibleException e2) {
					e2.getMessage();
				}
			}
			return taxAmount;
		}
}