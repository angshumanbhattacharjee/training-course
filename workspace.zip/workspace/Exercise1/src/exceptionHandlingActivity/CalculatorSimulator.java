package exceptionHandlingActivity;

public class CalculatorSimulator {

	public static void main(String[] args) {
		TaxCalculator tax= new TaxCalculator();
		double t1= tax.calculateTax("Ron",34000,false);
		double t2= tax.calculateTax("Tim",1000,true);
		double t3= tax.calculateTax("Jack",55000,true);
		System.out.println("Tax amount is: Rs"+t3);
		double t4= tax.calculateTax("",30000,true);
	}

}