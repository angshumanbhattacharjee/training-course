package exceptionHandlingActivity;

public class TaxNotEligibleException extends Exception {
	TaxNotEligibleException (){
		System.out.println("The employee does not need to pay tax");
	}
}