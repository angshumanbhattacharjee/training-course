package date_1aug2018;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class EmployeeService {
	public static void main(String[] args) {
		
				System.out.println("Employee count");
				Map<String, List<Employee>> empCount = EmployeeRepository.getEmployees().stream().collect(Collectors.groupingBy((Department)->EmployeeRepository.getDepartments()));
				for(String city:empCount.keySet()) {
					System.out.println(city+":"+empCount.get(city).size());
				}
	}
}
