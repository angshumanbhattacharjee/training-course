package Interfacing;

public class AdultUsers implements LibraryUser {
	int age;
	String bookType;
	AdultUsers(int age, String booktype){
		this.age=age;
		this.bookType=booktype;
	}
	public void registerAccount() {
		if (age>12) {
			System.out.println("You have successfully registered under an Adult");
		}
		else System.out.println("Sorry, Age must be greater than 12 to register under an Adult");
	}
	public void requestBook() {
		if (bookType=="Fiction") {
			System.out.println("Book issued successfully, please return the book within 7 days.");
		}
		else System.out.println("Oops, you are allowed to take only adult Fiction books.");
	}
}
