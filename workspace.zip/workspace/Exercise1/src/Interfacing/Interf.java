package Interfacing;

public interface Interf {
	public void add(int a,int b);
	default void m1(){
		System.out.println("default method");
	}
	static void m3(){
		System.out.println("static method");
	}
}
	class Test implements Interf
	{
		public static void main(String[] args) {
			Interf i=(a,b)->System.out.println("the sum is"+(a+b));
			i.add(10,20);
			i.m1();
			Interf.m3();
		}
	}

