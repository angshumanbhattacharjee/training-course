package ExerciseRandom;

public interface Interf1 {
	public boolean isOdd(int n);
}
