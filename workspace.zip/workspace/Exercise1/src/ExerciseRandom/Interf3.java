package ExerciseRandom;

public interface Interf3 {
	public boolean isPalindrome(int n);
}
