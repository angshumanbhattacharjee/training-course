package ExerciseRandom;

public interface Interf2 {
	public boolean isPrime(int n);
}
