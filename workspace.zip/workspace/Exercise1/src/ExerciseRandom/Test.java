package ExerciseRandom;

public class Test {

	public static void main(String[] args) {
		Interf1 i=(n)->{if(n%2==0) return false;
		else return true;
	};
	boolean c=i.isOdd(30);
	System.out.println(c);
	Interf2 j=(x)->{
		int flag=0;
		for(int k=1;k<Math.sqrt(x);k++) {
			if(x%k==0) flag=1;
			else flag=0;
		}
		if(flag==0) return true;
		else return false;
	};
	boolean d=j.isPrime(13);
	System.out.println(d);
	Interf3 z=(p)->{
		int m=p,t,s=0;
		while(p>0) {
			t=p%10;
			s=(s*10)+t;
			p/=10;
		}
		if(s==m) return true;
		else return false;
	};
	boolean r=z.isPalindrome(131);
	System.out.println(r);
}
}
