package Inheritance;

public class Manager extends Employee {
	Manager(long id, String name, String address, long phone,double salary){
		super(id,name,address,phone);
		this.basicSalary=salary;
	}
	public void calculateTransportAllowance() {
		double transportAllowance=0.15*basicSalary;
		System.out.println("Salary of manager after calculating transport allowance: Rs."+transportAllowance);
	}
}
