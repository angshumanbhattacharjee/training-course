package com.capgemini.hibernate;

import java.util.List;
import java.util.Map;
import java.util.Date;
import java.util.Iterator;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.SQLQuery;
import org.hibernate.Session; 
import org.hibernate.Transaction;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

public class ManageEmployee {
   private static SessionFactory factory; 
   
   ManageEmployee(){
	   try {
	         factory = new Configuration().configure().buildSessionFactory();
	      } catch (Throwable ex) { 
	         System.err.println("Failed to create sessionFactory object." + ex);
	         throw new ExceptionInInitializerError(ex); 
	      }
   }
   
   
   /* Method to CREATE an employee in the database using HQL */
   public Integer addEmployee(String fname, String lname, int salary){
      Session session = factory.openSession();
      Transaction tx = null;
      Integer employeeID = null;
      
      try {
         tx = session.beginTransaction();
         Employee employee = new Employee(fname, lname, salary);
         employeeID = (Integer) session.save(employee); 
         tx.commit();
      } catch (HibernateException e) {
         if (tx!=null) tx.rollback();
         e.printStackTrace(); 
      } finally {
         session.close(); 
      }
      return employeeID;
   }
   
   /* Method to  READ all the employees using HQL */
   public void listEmployees( ){
      Session session = factory.openSession();
      Transaction tx = null;
      
      try {
         tx = session.beginTransaction();
         List employees = session.createQuery("FROM Employee").list(); 
         for (Iterator iterator = employees.iterator(); iterator.hasNext();){
            Employee employee = (Employee) iterator.next(); 
            System.out.println("First Name: " + employee.getFirstName()); 
            System.out.println("  Last Name: " + employee.getLastName()); 
            System.out.println("  Salary: " + employee.getSalary()); 
         }
         tx.commit();
      } catch (HibernateException e) {
         if (tx!=null) tx.rollback();
         e.printStackTrace(); 
      } finally {
         session.close(); 
      }
   }
   
   /* Method to UPDATE salary for an employee using HQL */
   public void updateEmployee(Integer EmployeeID, int salary ){
      Session session = factory.openSession();
      Transaction tx = null;
      
      try {
         tx = session.beginTransaction();
         Employee employee = (Employee)session.get(Employee.class, EmployeeID); 
         employee.setSalary( salary );
		 session.update(employee); 
         tx.commit();
      } catch (HibernateException e) {
         if (tx!=null) tx.rollback();
         e.printStackTrace(); 
      } finally {
         session.close(); 
      }
   }
   
   /* Method to DELETE an employee from the records using HQL */
   public void deleteEmployee(Integer EmployeeID)
   {
      Session session = factory.openSession();
      Transaction tx = null;
      
      try {
         tx = session.beginTransaction();
         Employee employee = (Employee)session.get(Employee.class, EmployeeID); 
         session.delete(employee); 
         tx.commit();
      } catch (HibernateException e) {
         if (tx!=null) tx.rollback();
         e.printStackTrace(); 
      } finally {
         session.close(); 
      }
   }
   
   //list employees using Criteria
   public void listEmployees1( ) {
	      Session session = factory.openSession();
	      Transaction tx = null;
	      
	      try {
	         tx = session.beginTransaction();
	         Criteria cr = session.createCriteria(Employee.class);
	         
	         List employees = cr.list();

	         for (Iterator iterator = employees.iterator(); iterator.hasNext();){
	            Employee employee = (Employee) iterator.next(); 
	            System.out.print("First Name: " + employee.getFirstName()); 
	            System.out.print("  Last Name: " + employee.getLastName()); 
	            System.out.println("  Salary: " + employee.getSalary()); 
	         }
	         tx.commit();
	      } catch (HibernateException e) {
	         if (tx!=null) tx.rollback();
	         e.printStackTrace(); 
	      } finally {
	         session.close(); 
	      }
	   }
   
   //update employees using criteria
   public void updateEmployees1(Integer EmployeeID, int salary) {
	   Session session = factory.openSession();
	   Transaction tx = null;
	   
	   try {
		   tx = session.beginTransaction();
		   Criteria crit = session.createCriteria(Employee.class);
		   Employee e= new Employee();
		   e.setId(EmployeeID);
		   e.setSalary(salary);
		   
		   List employees = crit.list();

	         for (Iterator iterator = employees.iterator(); iterator.hasNext();){
	            Employee employee = (Employee) iterator.next(); 
	            System.out.println("First Name: " + employee.getFirstName()); 
	            System.out.println("  Last Name: " + employee.getLastName()); 
	            System.out.println("  Salary: " + employee.getSalary()); 
	         }
	         session.update(e);
	         tx.commit();
	} catch (HibernateException e) {
		// TODO: handle exception\
		if (tx!=null) tx.rollback();
        e.printStackTrace(); 
	}
	   finally {
	         session.close(); 
	      }  
   }
   
   
   public void criDel()
   {
	   Session session = factory.openSession();
	   Transaction tx = null;
	   try {
		
		   Employee emp = (Employee ) session.createCriteria(Employee.class).add(Restrictions.eq("id", 36)).uniqueResult();
		   session.delete(emp);
		   tx.commit();
	} catch (HibernateException e) {
		// TODO: handle exception
		if (tx!=null) tx.rollback();
        e.printStackTrace(); 
	}
	   finally {
	         session.close(); 
	      }    
   
   
   }

   
   //native sql
   public void listEmployeesScalar( ){
	      Session session = factory.openSession();
	      Transaction tx = null;
	      
	      try {
	         tx = session.beginTransaction();
	         String sql = "SELECT first_name, last_name, salary FROM EMPLOYEE";
	         SQLQuery query = session.createSQLQuery(sql);
	         query.addEntity(Employee.class);
	         List data = query.list();

	         for(Iterator iterator = data.iterator(); iterator.hasNext();) {
	            
	            Employee employee = (Employee) iterator.next(); 
	            System.out.println("First Name: " + employee.getFirstName()); 
	            System.out.println("  Last Name: " + employee.getLastName()); 
	            System.out.println("  Salary: " + employee.getSalary());
	         }
	         tx.commit();
	      } catch (HibernateException e) {
	         if (tx!=null) tx.rollback();
	         e.printStackTrace(); 
	      } finally {
	         session.close(); 
	      }
	   }
   
   public void listEmployeesEntity( ){
	      Session session = factory.openSession();
	      Transaction tx = null;
	      
	      try {
	         tx = session.beginTransaction();
	         String sql = "SELECT * FROM EMPLOYEE";
	         SQLQuery query = session.createSQLQuery(sql);
	         query.addEntity(Employee.class);
	         List employees = query.list();

	         for (Iterator iterator = employees.iterator(); iterator.hasNext();){
	            Employee employee = (Employee) iterator.next(); 
	            System.out.print("First Name: " + employee.getFirstName()); 
	            System.out.print("  Last Name: " + employee.getLastName()); 
	            System.out.println("  Salary: " + employee.getSalary()); 
	         }
	         tx.commit();
	      } catch (HibernateException e) {
	         if (tx!=null) tx.rollback();
	         e.printStackTrace(); 
	      } finally {
	         session.close(); 
	      }
	   }
}
