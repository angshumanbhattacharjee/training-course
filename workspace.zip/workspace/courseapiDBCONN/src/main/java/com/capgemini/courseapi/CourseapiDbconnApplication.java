package com.capgemini.courseapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CourseapiDbconnApplication {

	public static void main(String[] args) {
		SpringApplication.run(CourseapiDbconnApplication.class, args);
	}
}
